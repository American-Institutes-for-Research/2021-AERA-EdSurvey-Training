############################################### Slide 1	
############################################### Slide 2	
############################################### Slide 3	
############################################### Slide 4	
# to load the package	
library(EdSurvey)	
sdf <- readNAEP(system.file("extdata/data", "M36NT2PM.dat",	
                            package = "NAEPprimer"))	
############################################### Slide 5	
############################################### Slide 6	
############################################### Slide 7	
summary2(sdf, "composite")	
############################################### Slide 8	
summary2(sdf, "composite", weightVar = NULL)	
############################################### Slide 9	
summary2(sdf, "b017451")	
############################################### Slide 10	
summary2(sdf, "b017451", omittedLevels = TRUE)	
############################################### Slide 11	
############################################### Slide 12	
es1 <- edsurveyTable(composite ~ dsex + b017451, data = sdf)	
library(knitr)	
library(kableExtra)	
kable(es1$data, format="html") %>%	
  kable_styling(font_size = 16) %>%	
  scroll_box(width="100%", height = "30%")	
############################################### Slide 13	
es2 <- edsurveyTable(composite ~ dsex + b017451, data = sdf, pctAggregationLevel = 0)	
library(knitr)	
library(kableExtra)	
kable(es2$data, format="html") %>%	
  kable_styling(font_size = 16) %>%	
  scroll_box(width="100%", height = "75%")	
############################################### Slide 14	
############################################### Slide 15	
edexercise <- edsurveyTable(composite ~ iep + b013801,	
                            weightVar = 'origwt', data = sdf)	
edexercise	
############################################### Slide 16	
############################################### Slide 17	
############################################### Slide 18	
############################################### Slide 19	
library(EdSurvey)	
sdf <- readNAEP(system.file("extdata/data", "M36NT2PM.dat", package = "NAEPprimer"))	
lm1 <- lm.sdf(composite ~ b017451,	
              weightVar = 'origwt', data = sdf)	
summary(lm1)	
############################################### Slide 20	
lm2 <- lm.sdf(composite ~ dsex + b017451, 	
              weightVar = 'origwt', data = sdf)	
############################################### Slide 21	
summary(lm2)	
############################################### Slide 22	
summary(lm2, src = TRUE)	
############################################### Slide 23	
lm3 <- lm.sdf(composite ~ dsex + b017451, 	
              weightVar = 'origwt',	
              relevels = list(dsex = "Female"), data = sdf)	
############################################### Slide 24	
summary(lm3)	
############################################### Slide 25	
############################################### Slide 26	
lmexercise2 <- lm.sdf(composite ~ b017101 + b018201,	
                      weightVar = 'origwt', data = sdf)	
summary(lmexercise2)	
############################################### Slide 27	
############################################### Slide 28	
logit1 <- logit.sdf(I(b013801 %in% ">100") ~ dsex,	
                    weightVar = 'origwt', data = sdf)	
############################################### Slide 29	
summary(logit1)	
############################################### Slide 30	
oddsRatio(logit1)	
############################################### Slide 31	
############################################### Slide 32	
logitexercise1 <- logit.sdf(I(lep %in% "Yes") ~ b018201,	
                          weightVar = 'origwt', data = sdf)	
summary(logitexercise1)	
############################################### Slide 33	
############################################### Slide 34	
############################################### Slide 35	
############################################### Slide 36	
library(EdSurvey)	
sdf <- readNAEP(system.file("extdata/data", "M36NT2PM.dat", package="NAEPprimer"))	
showCutPoints(sdf)	
############################################### Slide 37	
achievementLevels("composite", data = sdf, returnDiscrete = TRUE, returnCumulative = FALSE)	
############################################### Slide 38	
achievementLevels("composite", data = sdf, returnDiscrete = FALSE, returnCumulative = TRUE)	
############################################### Slide 39	
achievementLevels(c("composite"), aggregateBy = NULL, data = sdf)	
############################################### Slide 40	
ach1 <- achievementLevels(c("composite", "dsex"), data = sdf)	
ach1$discrete	
############################################### Slide 41	
ach2 <- achievementLevels(c("composite", "dsex"), aggregateBy = "dsex", data = sdf)	
ach2$discrete	
############################################### Slide 42	
ach3 <- achievementLevels(c("composite", "dsex"), aggregateBy = "composite", data = sdf)	
ach3$discrete	
############################################### Slide 43	
iepFirst <- achievementLevels(c("composite", "dsex", "iep"),	
                              aggregateBy = c("iep", "dsex"), data = sdf)	
############################################### Slide 44	
iepFirst$discrete	
############################################### Slide 45	
############################################### Slide 46	
############################################### Slide 47	
exerciseAL <- achievementLevels(c("composite", "b018201"), aggregateBy = c("b018201"),	
                                data = sdf, returnCumulative = TRUE)	
exerciseAL$cumulative	
############################################### Slide 48	
############################################### Slide 49	
per <- percentile("composite", percentiles = c(25,50,75), data = sdf)	
per	
############################################### Slide 50	
############################################### Slide 51	
exercisePercentile <- percentile("composite", percentiles = c(10,25,50,75,90),	
                                 weightVar = "origwt", data = sdf)	
exercisePercentile	
############################################### Slide 52	
############################################### Slide 53	
vignette("introduction", package="EdSurvey")	
	
# There are additional functions that we couldn't cover!	
gap() #gap analysis	
cor.sdf() # Bivariate correlations using "Pearson", "Spearman", "polychoric", or "polyserial" methods	
edsurveyTable2pdf() # creating production ready summary tables	
cbind(), rbind(), append(), merge() # useful functions in processing data	
help(package = "EdSurvey")	
############################################### Slide 54	
############################################### Slide 55	
